
<!-- README.md is generated from README.Rmd. Please edit that file -->

# fisheriescape

<!-- badges: start -->
<!-- badges: end -->

R functions to help with the fisheriescape project.

## Installation

You can install the development version of fisheriescape with:

``` r
# install.packages("devtools")
devtools::install_github("JoleneSutton/fisheriescape")
```
